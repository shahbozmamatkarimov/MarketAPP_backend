export class CreateDistrictDto {}
