export class CreateProductDto {}
