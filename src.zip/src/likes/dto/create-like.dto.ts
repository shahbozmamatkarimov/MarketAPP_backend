export class CreateLikeDto {}
