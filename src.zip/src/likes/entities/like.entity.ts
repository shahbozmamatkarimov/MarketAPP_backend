export class Like {}
