export class CreateLocationDto {}
