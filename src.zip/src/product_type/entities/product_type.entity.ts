export class ProductType {}
