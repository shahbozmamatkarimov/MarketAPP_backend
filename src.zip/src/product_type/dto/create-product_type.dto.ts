export class CreateProductTypeDto {}
